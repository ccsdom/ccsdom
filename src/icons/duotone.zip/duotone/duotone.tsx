// src/icons/duotone.tsx
import { SvgIconProps } from "@mui/material";

import Home from "./HomeOutlined";
import FileLines from "./FileOutlined";
import Inbox from "./Inbox";
import Invoice from "./Invoice";
import UserProfile from "./UserProfile";
import RightFromBracket from "./Logout";

const duotone = {
  Home: (props: SvgIconProps) => <Home {...props} />,
  FileLines: (props: SvgIconProps) => <FileLines {...props} />,
  Inbox: (props: SvgIconProps) => <Inbox {...props} />,
  Invoice: (props: SvgIconProps) => <Invoice {...props} />,
  UserProfile: (props: SvgIconProps) => <UserProfile {...props} />,
  RightFromBracket: (props: SvgIconProps) => <RightFromBracket {...props} />,
};

export default duotone;
